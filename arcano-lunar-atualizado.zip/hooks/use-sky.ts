'use client'

import { useMemo } from 'react'
import { getMoonDay, getPlanets, getSunSignAt } from '@/lib/sky'
import { useNow } from './use-now'

export function useSky() {
  const now = useNow()
  const time = now?.getTime() ?? null

  return useMemo(() => {
    if (time === null) return null
    const date = new Date(time)
    return {
      date,
      moon: getMoonDay(date),
      sun: getSunSignAt(date),
      planets: getPlanets(date),
    }
  }, [time])
}
