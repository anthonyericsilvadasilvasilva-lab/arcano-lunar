'use client'

import { useSyncExternalStore } from 'react'

const HOUR = 3600000
const subscribe = (onChange: () => void) => {
  const id = setInterval(onChange, 60000)
  return () => clearInterval(id)
}
const getSnapshot = () => Math.floor(Date.now() / HOUR) * HOUR
const getServerSnapshot = () => null

export function useNow() {
  const ts = useSyncExternalStore(subscribe, getSnapshot, getServerSnapshot)
  return ts === null ? null : new Date(ts)
}
