# Arcano Lunar — versão revisada

Este pacote contém o projeto Next.js atualizado.

## O que mudou

- Identidade visual em ameixa/índigo profundo, com acentos dourados discretos.
- Navegação horizontal utilizável também em telas pequenas.
- Nova seção de fundamentos da astrologia clássica: sete astros, elementos, modalidades e dignidades essenciais.
- Regências tradicionais corrigidas: Marte rege Escorpião, Saturno rege Aquário e Júpiter rege Peixes.
- As dignidades simultâneas de Mercúrio em Virgem (domicílio + exaltação) e em Peixes (exílio + queda) são exibidas sem apagar uma condição pela outra.
- A seção de planetas explica que os dados são posições do céu do momento, não um mapa natal individual.
- O horóscopo foi corrigido para não chamar signos de casas astrológicas.
- As relações entre Lua e signo solar são descritas como relações por signo, sem afirmar aspectos exatos por grau.
- A tiragem de tarot é apresentada como prática simbólica separada dos cálculos astrológicos.
- Metadados, acessibilidade básica e configuração de build revisados. A opção que ignorava erros de TypeScript foi removida.

## Executar localmente

Requer Node.js compatível com Next.js 16 e pnpm.

```bash
pnpm install
pnpm dev
```

Para gerar a versão de produção:

```bash
pnpm build
pnpm start
```

## Observação de método

O site trabalha com o zodíaco tropical e com as regências tradicionais dos sete astros clássicos. As posições astronômicas são calculadas para o momento atual. Não há cálculo de mapa natal, casas, ascendente, aspectos exatos por grau, revolução solar ou progressões nesta versão, porque isso exigiria dados natais e módulos de cálculo próprios.

As associações de tarot e os textos de foco diário são correspondências simbólicas/editoriais, não resultados astronômicos nem previsões deterministas.
