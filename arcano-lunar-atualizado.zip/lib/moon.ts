import { MOON_PHASES, ZODIAC } from './astro-data'

const SYNODIC_MONTH = 29.530588853
const KNOWN_NEW_MOON = Date.UTC(2000, 0, 6, 18, 14)

export function getMoonInfo(date: Date) {
  const days = (date.getTime() - KNOWN_NEW_MOON) / 86400000
  const age = ((days % SYNODIC_MONTH) + SYNODIC_MONTH) % SYNODIC_MONTH
  const fraction = age / SYNODIC_MONTH
  const illumination = (1 - Math.cos(2 * Math.PI * fraction)) / 2
  const index = Math.floor(fraction * 8 + 0.5) % 8
  const daysToFull = ((0.5 - fraction + 1) % 1) * SYNODIC_MONTH
  const daysToNew = (1 - fraction) * SYNODIC_MONTH

  return {
    age,
    fraction,
    illumination,
    phase: MOON_PHASES[index],
    daysToFull,
    daysToNew,
  }
}

export function getSunSign(date: Date) {
  const month = date.getMonth() + 1
  const day = date.getDate()
  const sorted = [...ZODIAC].sort((a, b) =>
    a.start[0] === b.start[0] ? a.start[1] - b.start[1] : a.start[0] - b.start[0],
  )
  let sign = sorted[sorted.length - 1]
  for (const s of sorted) {
    if (month > s.start[0] || (month === s.start[0] && day >= s.start[1])) sign = s
  }
  return sign
}

export function moonLitPath(fraction: number, r = 50) {
  const waxing = fraction < 0.5
  const k = Math.cos(2 * Math.PI * fraction)
  const rx = Math.abs(k) * r
  const outerSweep = waxing ? 1 : 0
  const innerSweep = waxing ? (k > 0 ? 0 : 1) : k > 0 ? 1 : 0
  return `M ${r} 0 A ${r} ${r} 0 0 ${outerSweep} ${r} ${2 * r} A ${rx} ${r} 0 0 ${innerSweep} ${r} 0 Z`
}
