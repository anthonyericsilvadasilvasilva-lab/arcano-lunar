export type MoonPhase = {
  id: string
  name: string
  roman: string
  keyword: string
  card: string
  meaning: string
  ritual: string
}

export const MOON_PHASES: MoonPhase[] = [
  {
    id: 'nova',
    name: 'Lua Nova',
    roman: 'I',
    keyword: 'Semente',
    card: 'O Louco',
    meaning:
      'O céu escuro é uma página em branco. Tempo de silêncio, intenção e recomeços que ainda não precisam ser vistos.',
    ritual: 'Escreva uma intenção curta e guarde-a até a lua cheia.',
  },
  {
    id: 'crescente-concava',
    name: 'Crescente Côncava',
    roman: 'II',
    keyword: 'Impulso',
    card: 'O Mago',
    meaning:
      'O primeiro fio de luz pede coragem. A intenção encontra as ferramentas e começa a ganhar forma.',
    ritual: 'Dê o primeiro passo concreto, por menor que seja.',
  },
  {
    id: 'quarto-crescente',
    name: 'Quarto Crescente',
    roman: 'III',
    keyword: 'Decisão',
    card: 'O Carro',
    meaning:
      'Metade luz, metade sombra. Surgem obstáculos que testam a vontade; é hora de escolher e seguir.',
    ritual: 'Resolva uma pendência que vem adiando.',
  },
  {
    id: 'crescente-gibosa',
    name: 'Crescente Gibosa',
    roman: 'IV',
    keyword: 'Ajuste',
    card: 'A Temperança',
    meaning:
      'Quase cheia, a lua pede paciência e refinamento. Ajuste os detalhes antes da colheita.',
    ritual: 'Revise seus planos e corte o que for excesso.',
  },
  {
    id: 'cheia',
    name: 'Lua Cheia',
    roman: 'V',
    keyword: 'Revelação',
    card: 'A Lua',
    meaning:
      'Tudo vem à superfície: emoções, verdades, resultados. A luz plena ilumina o que estava oculto.',
    ritual: 'Agradeça o que floresceu e observe o que ficou exposto.',
  },
  {
    id: 'minguante-gibosa',
    name: 'Minguante Gibosa',
    roman: 'VI',
    keyword: 'Partilha',
    card: 'O Hierofante',
    meaning:
      'A luz começa a recuar. Momento de ensinar, compartilhar e integrar o que foi aprendido.',
    ritual: 'Conte a alguém algo que você descobriu.',
  },
  {
    id: 'quarto-minguante',
    name: 'Quarto Minguante',
    roman: 'VII',
    keyword: 'Desapego',
    card: 'A Morte',
    meaning:
      'Uma nova encruzilhada, agora voltada para dentro. Solte hábitos, objetos e histórias que pesam.',
    ritual: 'Descarte algo que já cumpriu seu papel.',
  },
  {
    id: 'minguante-balsamica',
    name: 'Minguante Balsâmica',
    roman: 'VIII',
    keyword: 'Repouso',
    card: 'O Eremita',
    meaning:
      'O último sopro de luz antes do escuro. Descanso, sonho e recolhimento preparam o próximo ciclo.',
    ritual: 'Durma cedo e anote seus sonhos ao acordar.',
  },
]

export type ZodiacSign = {
  name: string
  symbol: string
  dates: string
  element: 'Fogo' | 'Terra' | 'Ar' | 'Água'
  modality: 'Cardinal' | 'Fixo' | 'Mutável'
  ruler: string
  card: string
  start: [number, number]
  essence: string
}

export const ZODIAC: ZodiacSign[] = [
  { name: 'Áries', symbol: '♈︎', dates: '21 mar — 19 abr', element: 'Fogo', modality: 'Cardinal', ruler: 'Marte', card: 'O Imperador', start: [3, 21], essence: 'iniciativa' },
  { name: 'Touro', symbol: '♉︎', dates: '20 abr — 20 mai', element: 'Terra', modality: 'Fixo', ruler: 'Vênus', card: 'O Hierofante', start: [4, 20], essence: 'constância' },
  { name: 'Gêmeos', symbol: '♊︎', dates: '21 mai — 20 jun', element: 'Ar', modality: 'Mutável', ruler: 'Mercúrio', card: 'Os Enamorados', start: [5, 21], essence: 'curiosidade' },
  { name: 'Câncer', symbol: '♋︎', dates: '21 jun — 22 jul', element: 'Água', modality: 'Cardinal', ruler: 'Lua', card: 'O Carro', start: [6, 21], essence: 'cuidado' },
  { name: 'Leão', symbol: '♌︎', dates: '23 jul — 22 ago', element: 'Fogo', modality: 'Fixo', ruler: 'Sol', card: 'A Força', start: [7, 23], essence: 'expressão' },
  { name: 'Virgem', symbol: '♍︎', dates: '23 ago — 22 set', element: 'Terra', modality: 'Mutável', ruler: 'Mercúrio', card: 'O Eremita', start: [8, 23], essence: 'discernimento' },
  { name: 'Libra', symbol: '♎︎', dates: '23 set — 22 out', element: 'Ar', modality: 'Cardinal', ruler: 'Vênus', card: 'A Justiça', start: [9, 23], essence: 'equilíbrio' },
  { name: 'Escorpião', symbol: '♏︎', dates: '23 out — 21 nov', element: 'Água', modality: 'Fixo', ruler: 'Marte', card: 'A Morte', start: [10, 23], essence: 'transformação' },
  { name: 'Sagitário', symbol: '♐︎', dates: '22 nov — 21 dez', element: 'Fogo', modality: 'Mutável', ruler: 'Júpiter', card: 'A Temperança', start: [11, 22], essence: 'expansão' },
  { name: 'Capricórnio', symbol: '♑︎', dates: '22 dez — 19 jan', element: 'Terra', modality: 'Cardinal', ruler: 'Saturno', card: 'O Diabo', start: [12, 22], essence: 'estrutura' },
  { name: 'Aquário', symbol: '♒︎', dates: '20 jan — 18 fev', element: 'Ar', modality: 'Fixo', ruler: 'Saturno', card: 'A Estrela', start: [1, 20], essence: 'visão' },
  { name: 'Peixes', symbol: '♓︎', dates: '19 fev — 20 mar', element: 'Água', modality: 'Mutável', ruler: 'Júpiter', card: 'A Lua', start: [2, 19], essence: 'intuição' },
]

export type TarotCard = {
  numeral: string
  name: string
  upright: string
  message: string
}

export const MAJOR_ARCANA: TarotCard[] = [
  { numeral: '0', name: 'O Louco', upright: 'Começo · Liberdade · Fé', message: 'Salte. O caminho se revela a quem ousa dar o primeiro passo.' },
  { numeral: 'I', name: 'O Mago', upright: 'Vontade · Habilidade · Ação', message: 'Você já tem tudo o que precisa sobre a mesa. Use.' },
  { numeral: 'II', name: 'A Sacerdotisa', upright: 'Intuição · Mistério · Silêncio', message: 'A resposta não está fora. Escute o que fala baixinho.' },
  { numeral: 'III', name: 'A Imperatriz', upright: 'Fertilidade · Abundância · Corpo', message: 'Cultive. O que é nutrido com carinho cresce.' },
  { numeral: 'IV', name: 'O Imperador', upright: 'Estrutura · Autoridade · Ordem', message: 'Firme os alicerces antes de erguer as paredes.' },
  { numeral: 'V', name: 'O Hierofante', upright: 'Tradição · Ensino · Fé', message: 'Há sabedoria nos caminhos já trilhados.' },
  { numeral: 'VI', name: 'Os Enamorados', upright: 'Escolha · União · Valores', message: 'Escolha com o coração alinhado ao que você acredita.' },
  { numeral: 'VII', name: 'O Carro', upright: 'Direção · Vitória · Controle', message: 'Segure as rédeas. A vitória vem do foco.' },
  { numeral: 'VIII', name: 'A Força', upright: 'Coragem · Paciência · Doçura', message: 'A verdadeira força é gentil e não precisa gritar.' },
  { numeral: 'IX', name: 'O Eremita', upright: 'Introspecção · Busca · Solidão', message: 'Recolha-se. A lanterna ilumina melhor no escuro.' },
  { numeral: 'X', name: 'A Roda da Fortuna', upright: 'Ciclos · Destino · Mudança', message: 'Tudo gira. O que desce também volta a subir.' },
  { numeral: 'XI', name: 'A Justiça', upright: 'Verdade · Equilíbrio · Causa', message: 'Cada escolha tem seu peso. Seja honesto consigo.' },
  { numeral: 'XII', name: 'O Enforcado', upright: 'Pausa · Entrega · Perspectiva', message: 'Mude o ângulo e o problema mudará de forma.' },
  { numeral: 'XIII', name: 'A Morte', upright: 'Fim · Transformação · Renovação', message: 'Algo termina para que algo novo possa nascer.' },
  { numeral: 'XIV', name: 'A Temperança', upright: 'Moderação · Alquimia · Calma', message: 'Misture os opostos com paciência. O meio-termo cura.' },
  { numeral: 'XV', name: 'O Diabo', upright: 'Apego · Desejo · Sombra', message: 'Olhe para as correntes. Muitas estão abertas.' },
  { numeral: 'XVI', name: 'A Torre', upright: 'Ruptura · Revelação · Queda', message: 'O que é falso desmorona. O que é real permanece.' },
  { numeral: 'XVII', name: 'A Estrela', upright: 'Esperança · Cura · Inspiração', message: 'Depois da tempestade, a luz volta a guiar.' },
  { numeral: 'XVIII', name: 'A Lua', upright: 'Ilusão · Sonho · Inconsciente', message: 'Nem tudo é o que parece. Confie na intuição.' },
  { numeral: 'XIX', name: 'O Sol', upright: 'Alegria · Clareza · Vitalidade', message: 'Permita-se brilhar sem pedir desculpas.' },
  { numeral: 'XX', name: 'O Julgamento', upright: 'Despertar · Chamado · Perdão', message: 'Atenda ao chamado. É hora de renascer.' },
  { numeral: 'XXI', name: 'O Mundo', upright: 'Conclusão · Integração · Plenitude', message: 'Um ciclo se completa. Celebre a jornada inteira.' },
]
