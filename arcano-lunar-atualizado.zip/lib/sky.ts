import { Body, Ecliptic, EclipticGeoMoon, GeoVector, Illumination, MoonPhase as moonPhaseAngle, SearchMoonQuarter, SunPosition } from 'astronomy-engine'
import { MOON_PHASES, ZODIAC, type ZodiacSign } from './astro-data'

const DAY = 86400000
const SYNODIC_MONTH = 29.530588853

export type PlanetName = 'Mercúrio' | 'Vênus' | 'Marte' | 'Júpiter' | 'Saturno'
export type Condition = 'domicílio' | 'domicílio + exaltação' | 'exílio + queda' | 'exaltação' | 'exílio' | 'queda' | 'peregrino'

const BODIES: Record<PlanetName, Body> = {
  Mercúrio: Body.Mercury,
  Vênus: Body.Venus,
  Marte: Body.Mars,
  Júpiter: Body.Jupiter,
  Saturno: Body.Saturn,
}

const DIGNITIES: Record<PlanetName, { domicile: string[]; exaltation: string; exile: string[]; fall: string }> = {
  Mercúrio: { domicile: ['Gêmeos', 'Virgem'], exaltation: 'Virgem', exile: ['Sagitário', 'Peixes'], fall: 'Peixes' },
  Vênus: { domicile: ['Touro', 'Libra'], exaltation: 'Peixes', exile: ['Escorpião', 'Áries'], fall: 'Virgem' },
  Marte: { domicile: ['Áries', 'Escorpião'], exaltation: 'Capricórnio', exile: ['Libra', 'Touro'], fall: 'Câncer' },
  Júpiter: { domicile: ['Sagitário', 'Peixes'], exaltation: 'Câncer', exile: ['Gêmeos', 'Virgem'], fall: 'Capricórnio' },
  Saturno: { domicile: ['Capricórnio', 'Aquário'], exaltation: 'Libra', exile: ['Câncer', 'Leão'], fall: 'Áries' },
}

export const TRADITIONAL_RULER: Record<string, PlanetName | 'Sol' | 'Lua'> = {
  Áries: 'Marte',
  Touro: 'Vênus',
  Gêmeos: 'Mercúrio',
  Câncer: 'Lua',
  Leão: 'Sol',
  Virgem: 'Mercúrio',
  Libra: 'Vênus',
  Escorpião: 'Marte',
  Sagitário: 'Júpiter',
  Capricórnio: 'Saturno',
  Aquário: 'Saturno',
  Peixes: 'Júpiter',
}

export function signFromLongitude(lon: number): ZodiacSign {
  const normalized = ((lon % 360) + 360) % 360
  return ZODIAC[Math.floor(normalized / 30)]
}

function planetLongitude(body: Body, date: Date) {
  return Ecliptic(GeoVector(body, date, true)).elon
}

function conditionOf(planet: PlanetName, sign: string): Condition {
  const d = DIGNITIES[planet]
  if (d.domicile.includes(sign) && d.exaltation === sign) return 'domicílio + exaltação' as Condition
  if (d.domicile.includes(sign)) return 'domicílio'
  if (d.exaltation === sign) return 'exaltação'
  if (d.exile.includes(sign) && d.fall === sign) return 'exílio + queda' as Condition
  if (d.exile.includes(sign)) return 'exílio'
  if (d.fall === sign) return 'queda'
  return 'peregrino'
}

const SEARCH_LIMIT = 150

function findSignBoundary(body: Body, from: Date, signIndex: number, direction: 1 | -1) {
  for (let i = 1; i <= SEARCH_LIMIT; i++) {
    const d = new Date(from.getTime() + direction * i * DAY)
    if (Math.floor(planetLongitude(body, d) / 30) !== signIndex) return { days: i, date: d }
  }
  return null
}

export type PlanetState = {
  name: PlanetName
  sign: ZodiacSign
  degree: number
  retrograde: boolean
  condition: Condition
  since: Date | null
  until: Date | null
  daysLeft: number | null
  progress: number
}

export function getPlanets(date: Date): PlanetState[] {
  return (Object.keys(BODIES) as PlanetName[]).map((name) => {
    const body = BODIES[name]
    const lon = planetLongitude(body, date)
    const next = planetLongitude(body, new Date(date.getTime() + DAY))
    const delta = ((next - lon + 540) % 360) - 180
    const signIndex = Math.floor(lon / 30)
    const sign = ZODIAC[signIndex]
    const back = findSignBoundary(body, date, signIndex, -1)
    const ahead = findSignBoundary(body, date, signIndex, 1)
    const elapsed = back?.days ?? SEARCH_LIMIT
    const remaining = ahead?.days ?? SEARCH_LIMIT
    return {
      name,
      sign,
      degree: Math.floor(lon % 30),
      retrograde: delta < 0,
      condition: conditionOf(name, sign.name),
      since: back ? new Date(back.date.getTime() + DAY) : null,
      until: ahead?.date ?? null,
      daysLeft: ahead?.days ?? null,
      progress: elapsed / (elapsed + remaining),
    }
  })
}

export type MoonDay = {
  date: Date
  angle: number
  fraction: number
  illumination: number
  phase: (typeof MOON_PHASES)[number]
  sign: ZodiacSign
  lunarDay: number
  age: number
}

export function getMoonDay(date: Date): MoonDay {
  const angle = moonPhaseAngle(date)
  const fraction = angle / 360
  const index = Math.floor(fraction * 8 + 0.5) % 8
  const age = fraction * SYNODIC_MONTH
  return {
    date,
    angle,
    fraction,
    illumination: Illumination(Body.Moon, date).phase_fraction,
    phase: MOON_PHASES[index],
    sign: signFromLongitude(EclipticGeoMoon(date).lon),
    lunarDay: Math.floor(age) + 1,
    age,
  }
}

export function getSunSignAt(date: Date) {
  return signFromLongitude(SunPosition(date).elon)
}

const QUARTER_NAMES = ['Lua Nova', 'Quarto Crescente', 'Lua Cheia', 'Quarto Minguante']

export function getMonthQuarters(year: number, month: number) {
  const start = new Date(year, month, 1)
  const end = new Date(year, month + 1, 1)
  const quarters: { name: string; date: Date }[] = []
  let q = SearchMoonQuarter(new Date(start.getTime() - 8 * DAY))
  while (q.time.date < end) {
    if (q.time.date >= start) quarters.push({ name: QUARTER_NAMES[q.quarter], date: q.time.date })
    q = SearchMoonQuarter(new Date(q.time.date.getTime() + DAY))
  }
  return quarters
}

export function relationBetween(a: ZodiacSign, b: ZodiacSign) {
  const distance = Math.abs(ZODIAC.indexOf(a) - ZODIAC.indexOf(b))
  const steps = Math.min(distance, 12 - distance)
  if (steps === 0) return 'conjunção'
  if (steps === 2) return 'sextil'
  if (steps === 3) return 'quadratura'
  if (steps === 4) return 'trígono'
  if (steps === 6) return 'oposição'
  return 'neutro'
}
