import type { MoonPhase, TarotCard, ZodiacSign } from './astro-data'
import type { Condition, MoonDay, PlanetName, PlanetState } from './sky'
import { TRADITIONAL_RULER, relationBetween } from './sky'

export const MOON_IN_SIGN: Record<string, { tone: string; focus: string }> = {
  Áries: { tone: 'impulsiva e corajosa', focus: 'Iniciar' },
  Touro: { tone: 'calma e sensorial', focus: 'Enraizar' },
  Gêmeos: { tone: 'curiosa e falante', focus: 'Conversar' },
  Câncer: { tone: 'sensível e protetora', focus: 'Acolher' },
  Leão: { tone: 'expansiva e criativa', focus: 'Brilhar' },
  Virgem: { tone: 'atenta e organizada', focus: 'Ordenar' },
  Libra: { tone: 'gentil e diplomática', focus: 'Equilibrar' },
  Escorpião: { tone: 'intensa e profunda', focus: 'Transformar' },
  Sagitário: { tone: 'otimista e inquieta', focus: 'Explorar' },
  Capricórnio: { tone: 'séria e ambiciosa', focus: 'Construir' },
  Aquário: { tone: 'livre e inventiva', focus: 'Inovar' },
  Peixes: { tone: 'sonhadora e intuitiva', focus: 'Sentir' },
}

export const PLANET_DOMAIN: Record<PlanetName, string> = {
  Mercúrio: 'a mente, as palavras e os acordos',
  Vênus: 'o afeto, a beleza e aquilo que você valoriza',
  Marte: 'a ação, o desejo e a coragem',
  Júpiter: 'a fé, a sorte e o crescimento',
  Saturno: 'os limites, o tempo e as responsabilidades',
}

export const CONDITION_LABEL: Record<Condition, string> = {
  domicílio: 'Domicílio',
  'domicílio + exaltação': 'Domicílio + exaltação',
  exaltação: 'Exaltação',
  'exílio + queda': 'Exílio + queda',
  exílio: 'Exílio',
  queda: 'Queda',
  peregrino: 'Peregrino',
}

const CONDITION_TEXT: Record<Condition, string> = {
  domicílio: 'está em casa e age com naturalidade e força',
  'domicílio + exaltação': 'reúne domicílio e exaltação: uma dignidade essencial especialmente forte',
  exaltação: 'está exaltado e oferece o seu melhor',
  'exílio + queda': 'reúne exílio e queda: duas debilidades essenciais no mesmo signo',
  exílio: 'está longe de casa e pede mais esforço consciente',
  queda: 'está em queda, e sua energia chega tímida ou desconfiada',
  peregrino: 'encontra-se sem dignidade essencial maior e recebe a coloração do signo',
}

const TITLES: Record<PlanetName, Record<Condition | 'retrógrado', string>> = {
  Mercúrio: { domicílio: 'Mente afiada', 'domicílio + exaltação': 'Mente e expressão em potência', 'exílio + queda': 'Revisão profunda das ideias', exaltação: 'A palavra exata', exílio: 'Pensamentos dispersos', queda: 'Névoa nas ideias', peregrino: 'Mensagens no ar', retrógrado: 'Reler antes de enviar' },
  Vênus: { domicílio: 'O coração em casa', 'domicílio + exaltação': 'Afeto em sua própria natureza', 'exílio + queda': 'Afetos em terreno exigente', exaltação: 'Amor sem medida', exílio: 'Afeto em prova', queda: 'O olhar crítico', peregrino: 'Encontros sutis', retrógrado: 'Amores que retornam' },
  Marte: { domicílio: 'Força total', 'domicílio + exaltação': 'Ação com força e direção', 'exílio + queda': 'Ação sob forte contenção', exaltação: 'Disciplina em ação', exílio: 'Impulso contido', queda: 'Raiva silenciosa', peregrino: 'Impulso silencioso', retrógrado: 'Recuar para avançar' },
  Júpiter: { domicílio: 'Portas abertas', 'domicílio + exaltação': 'Expansão em sua própria natureza', 'exílio + queda': 'Crescimento com limites', exaltação: 'Generosidade plena', exílio: 'Excesso de opções', queda: 'Fé sob medida', peregrino: 'Horizonte amplo', retrógrado: 'Crescer por dentro' },
  Saturno: { domicílio: 'Alicerces firmes', 'domicílio + exaltação': 'Estrutura e autoridade fortalecidas', 'exílio + queda': 'Estrutura sob tensão', exaltação: 'Justiça no tempo', exílio: 'Peso nas costas', queda: 'Paciência à prova', peregrino: 'Lições lentas', retrógrado: 'Devagar e sempre se vence' },
}

export function planetTitle(p: PlanetState) {
  return p.retrograde ? TITLES[p.name].retrógrado : TITLES[p.name][p.condition]
}

export function planetMessage(p: PlanetState) {
  const motion = p.retrograde
    ? ' Em movimento retrógrado, a tradição sugere atenção à revisão e à retomada de assuntos.'
    : ''
  return `${p.name} em ${p.sign.name} ${CONDITION_TEXT[p.condition]}. Atinge ${PLANET_DOMAIN[p.name]}.${motion}`
}

export function dailyFocus(moon: MoonDay) {
  const m = MOON_IN_SIGN[moon.sign.name]
  return {
    focus: m.focus,
    text: `Com a ${moon.phase.name} em ${moon.sign.name}, o dia fica ${m.tone}. ${moon.phase.meaning}`,
  }
}

const RELATION_TEXT: Record<ReturnType<typeof relationBetween>, string> = {
  conjunção: 'A Lua está no mesmo signo do seu Sol: há uma ênfase simbólica nesse território da experiência.',
  sextil: 'A Lua forma uma relação de sextil por signo com seu Sol: pequenas oportunidades podem surgir por meio de conversas e movimento.',
  quadratura: 'A Lua forma uma relação de quadratura por signo com seu Sol: diferenças podem mostrar onde é preciso ajustar a rota.',
  trígono: 'A Lua forma uma relação de trígono por signo com seu Sol: procure caminhos de cooperação e continuidade.',
  oposição: 'A Lua está no signo oposto ao seu Sol: relações e contrastes podem funcionar como espelho.',
  neutro: 'A Lua passa discreta pelo seu céu: um dia para observar sem pressa.',
}

const ELEMENT_ADVICE: Record<ZodiacSign['element'], string> = {
  Fogo: 'Canalize o entusiasmo em uma única direção.',
  Terra: 'Pequenos gestos concretos sustentam grandes mudanças.',
  Ar: 'Organize as ideias antes de agir.',
  Água: 'Acolha o que sente sem precisar resolver tudo hoje.',
}

export function signReading(sign: ZodiacSign, moon: MoonDay, planets: PlanetState[], sunSign: ZodiacSign) {
  const rulerName = TRADITIONAL_RULER[sign.name]
  const ruler = planets.find((p) => p.name === rulerName)
  let rulerText: string
  if (ruler) {
    rulerText = `Seu regente, ${ruler.name}, está em ${ruler.sign.name}${ruler.retrograde ? ' e retrógrado' : ''}: ${CONDITION_TEXT[ruler.condition]}. Isso colore ${PLANET_DOMAIN[ruler.name]}.`
  } else if (rulerName === 'Lua') {
    rulerText = `Seu regente é a própria Lua, hoje ${MOON_IN_SIGN[moon.sign.name].tone} em ${moon.sign.name}. Siga o humor do céu.`
  } else {
    rulerText = `Seu regente é o Sol, atualmente em ${sunSign.name}. Na leitura tradicional, observe a condição solar junto à fase e à posição da Lua.`
  }
  return {
    lunar: `${moon.phase.keyword} é a palavra desta ${moon.phase.name}. ${ELEMENT_ADVICE[sign.element]}`,
    relation: RELATION_TEXT[relationBetween(sign, moon.sign)],
    ruler: rulerText,
    rulerName,
  }
}

const SLOT_PREFIX = [
  'No passado, sob a energia de',
  'No presente, iluminada pela',
  'No futuro, guiada pela',
]

export function tarotReading(card: TarotCard, slot: number, moon: MoonDay, phase: MoonPhase) {
  const isPhaseCard = card.name === phase.card
  const extra = isPhaseCard
    ? ` ${card.name} é o próprio Arcano desta fase: preste atenção redobrada.`
    : ''
  return `${SLOT_PREFIX[slot]} ${phase.name} em ${moon.sign.name}, ${card.name} diz: ${card.message}${extra}`
}
