import { Horoscope } from '@/components/horoscope'
import { ClassicalGuide } from '@/components/classical-guide'
import { MoonDashboard } from '@/components/moon-dashboard'
import { Planets } from '@/components/planets'
import { Reveal } from '@/components/reveal'
import { SiteFooter } from '@/components/site-footer'
import { SiteHeader } from '@/components/site-header'
import { TarotDraw } from '@/components/tarot-draw'

export default function Page() {
  return (
    <div className="film-grain min-h-screen">
      <SiteHeader />
      <main>
        <MoonDashboard />
        <Reveal>
          <ClassicalGuide />
        </Reveal>
        <Reveal>
          <Planets />
        </Reveal>
        <Reveal>
          <TarotDraw />
        </Reveal>
        <Reveal>
          <Horoscope />
        </Reveal>
      </main>
      <SiteFooter />
    </div>
  )
}
