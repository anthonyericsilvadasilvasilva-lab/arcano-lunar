const LINKS = [
  { href: '#hoje', label: 'Lua de hoje' },
  { href: '#fundamentos', label: 'Fundamentos' },
  { href: '#planetas', label: 'Céu atual' },
  { href: '#tarot', label: 'Tarot' },
  { href: '#horoscopo', label: 'Horóscopo' },
]

export function SiteHeader() {
  return (
    <header className="sticky top-0 z-40 border-b bg-background/85 backdrop-blur-sm">
      <div className="mx-auto flex max-w-6xl items-center justify-between gap-4 px-4 py-3 sm:gap-6 sm:px-5 sm:py-4">
        <a href="#" className="shrink-0 text-xl italic tracking-tight sm:text-2xl">
          Arcano Lunar
        </a>
        <nav aria-label="Principal" className="min-w-0 flex-1 overflow-x-auto">
          <ul className="flex min-w-max gap-5 px-1 font-mono text-[9px] uppercase tracking-[0.16em] text-muted-foreground sm:gap-7 sm:text-[10px]">
            {LINKS.map((link) => (
              <li key={link.href}>
                <a href={link.href} className="transition-colors hover:text-foreground">
                  {link.label}
                </a>
              </li>
            ))}
          </ul>
        </nav>
        <span className="hidden shrink-0 font-mono text-[9px] uppercase tracking-[0.12em] text-muted-foreground sm:block">
          ALMANAQUE · 2026
        </span>
      </div>
    </header>
  )
}
