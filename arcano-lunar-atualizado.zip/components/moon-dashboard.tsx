'use client'

import { useMemo, useState } from 'react'
import { useSky } from '@/hooks/use-sky'
import { dailyFocus } from '@/lib/messages'
import { getMoonDay, getMonthQuarters, type MoonDay } from '@/lib/sky'
import { cn } from '@/lib/utils'
import { AnimatedMoon } from './animated-moon'
import { MoonGlyph } from './moon-glyph'

const longDate = new Intl.DateTimeFormat('pt-BR', { weekday: 'long', day: 'numeric', month: 'long' })
const monthName = new Intl.DateTimeFormat('pt-BR', { month: 'long', year: 'numeric' })
const shortDay = new Intl.DateTimeFormat('pt-BR', { day: 'numeric', month: 'short' })
const time = new Intl.DateTimeFormat('pt-BR', { hour: '2-digit', minute: '2-digit' })
const WEEKDAYS = ['D', 'S', 'T', 'Q', 'Q', 'S', 'S']

function sameDay(a: Date, b: Date) {
  return a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth() && a.getDate() === b.getDate()
}

export function MoonDashboard() {
  const sky = useSky()
  const [selectedDay, setSelectedDay] = useState<number | null>(null)

  const month = useMemo(() => {
    if (!sky) return null
    const y = sky.date.getFullYear()
    const m = sky.date.getMonth()
    const total = new Date(y, m + 1, 0).getDate()
    const days = Array.from({ length: total }, (_, i) => getMoonDay(new Date(y, m, i + 1, 12)))
    return { days, offset: new Date(y, m, 1).getDay(), quarters: getMonthQuarters(y, m), label: monthName.format(sky.date) }
  }, [sky])

  if (!sky || !month) {
    return (
      <section id="hoje" className="border-b">
        <div className="mx-auto flex min-h-[80vh] max-w-6xl items-center justify-center px-5">
          <div className="size-56 animate-pulse rounded-full bg-muted" />
        </div>
      </section>
    )
  }

  const isToday = selectedDay === null || selectedDay === sky.date.getDate()
  const moon: MoonDay = isToday ? sky.moon : month.days[selectedDay - 1]
  const focus = dailyFocus(moon)

  return (
    <section id="hoje" className="scroll-mt-16 border-b">
      <div className="mx-auto max-w-6xl px-5 pb-16 pt-10 md:pt-16">
        <div className="grid gap-10 md:grid-cols-[1fr_1.1fr] md:items-center" aria-live="polite">
          <div className="mx-auto w-full max-w-sm">
            <AnimatedMoon fraction={moon.fraction} />
          </div>

          <div className="flex flex-col gap-6">
            <div className="flex flex-col gap-3">
              <p className="font-mono text-[11px] uppercase tracking-[0.25em] text-muted-foreground">
                {isToday ? 'Hoje · ' : ''}
                {longDate.format(moon.date)}
              </p>
              <h1 className="text-balance text-5xl font-light leading-none md:text-7xl">
                <em>{moon.phase.name}</em>
              </h1>
              <p className="font-mono text-[11px] uppercase tracking-[0.25em] text-muted-foreground">
                {moon.lunarDay}º dia lunar · Lua em {moon.sign.name}
              </p>
            </div>

            <div className="flex flex-col gap-2 border-l-2 border-foreground pl-5">
              <p className="font-mono text-[10px] uppercase tracking-[0.3em] text-muted-foreground">
                Foco do dia · {focus.focus}
              </p>
              <p className="text-pretty text-xl leading-relaxed md:text-2xl">{focus.text}</p>
            </div>

            <p className="max-w-xl text-sm leading-relaxed text-muted-foreground">Cálculo astronômico da fase e da posição zodiacal da Lua. As sugestões abaixo são correspondências simbólicas, não previsões deterministas.</p>
            <dl className="grid grid-cols-2 border-l border-t sm:grid-cols-4">
              <Stat label="Iluminação" value={`${Math.round(moon.illumination * 100)}%`} />
              <Stat label="Signo lunar" value={moon.sign.name} />
              <Stat label="Correspondência simbólica" value={moon.phase.card} />
              <Stat label="Sol em" value={sky.sun.name} />
            </dl>

            <p className="text-lg italic text-muted-foreground">Ritual: {moon.phase.ritual}</p>
          </div>
        </div>

        <div className="mt-16 border-t pt-10">
          <div className="flex flex-wrap items-end justify-between gap-4">
            <div>
              <p className="font-mono text-[11px] uppercase tracking-[0.3em] text-muted-foreground">Calendário lunar</p>
              <h2 className="mt-2 text-4xl font-light first-letter:uppercase md:text-5xl">{month.label}</h2>
            </div>
            {!isToday && (
              <button
                type="button"
                onClick={() => setSelectedDay(null)}
                className="border border-foreground px-4 py-2 font-mono text-[11px] uppercase tracking-[0.2em] transition-colors hover:bg-foreground hover:text-background"
              >
                Voltar para hoje
              </button>
            )}
          </div>

          <div className="mt-8 grid grid-cols-7 gap-px border bg-border" role="grid" aria-label={`Fases da lua em ${month.label}`}>
            {WEEKDAYS.map((w, i) => (
              <div key={i} className="bg-background py-2 text-center font-mono text-[10px] tracking-[0.2em] text-muted-foreground" aria-hidden="true">
                {w}
              </div>
            ))}
            {Array.from({ length: month.offset }).map((_, i) => (
              <div key={`empty-${i}`} className="bg-background" aria-hidden="true" />
            ))}
            {month.days.map((d) => {
              const day = d.date.getDate()
              const today = sameDay(d.date, sky.date)
              const active = day === moon.date.getDate()
              const quarter = month.quarters.find((q) => sameDay(q.date, d.date))
              return (
                <button
                  key={day}
                  type="button"
                  onClick={() => setSelectedDay(day)}
                  aria-pressed={active}
                  aria-label={`${day}: ${d.phase.name}, Lua em ${d.sign.name}`}
                  className={cn(
                    'flex flex-col items-center gap-1.5 bg-background px-1 py-3 transition-colors hover:bg-accent focus-visible:outline-2 focus-visible:-outline-offset-2 focus-visible:outline-foreground',
                    active && 'bg-foreground text-background hover:bg-foreground',
                  )}
                >
                  <span className={cn('font-mono text-[11px]', today && !active && 'underline underline-offset-4')}>{day}</span>
                  <MoonGlyph fraction={d.fraction} textured className="size-7 sm:size-10" />
                  <span className={cn('h-3 font-mono text-[8px] uppercase tracking-wider', active ? 'text-background/70' : 'text-muted-foreground')}>
                    {quarter ? quarter.name.replace('Quarto ', '').replace('Lua ', '') : ''}
                  </span>
                </button>
              )
            })}
          </div>

          <ul className="mt-6 grid grid-cols-2 gap-px border bg-border sm:grid-cols-4">
            {month.quarters.map((q) => (
              <li key={q.date.toISOString()} className="flex flex-col gap-1 bg-background p-4">
                <span className="font-mono text-[10px] uppercase tracking-[0.2em] text-muted-foreground">{q.name}</span>
                <span className="text-xl">{shortDay.format(q.date)}</span>
                <span className="font-mono text-[10px] text-muted-foreground">às {time.format(q.date)}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </section>
  )
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex flex-col gap-1 border-b border-r p-3">
      <dt className="font-mono text-[9px] uppercase tracking-[0.2em] text-muted-foreground">{label}</dt>
      <dd className="text-lg leading-tight">{value}</dd>
    </div>
  )
}
