type SectionHeadingProps = {
  index: string
  eyebrow: string
  title: string
  description?: string
}

export function SectionHeading({ index, eyebrow, title, description }: SectionHeadingProps) {
  return (
    <div className="flex flex-col gap-4 md:flex-row md:items-end md:justify-between">
      <div className="flex items-baseline gap-5">
        <span className="font-mono text-sm text-muted-foreground">{index}.</span>
        <div>
          <p className="font-mono text-[11px] uppercase tracking-[0.3em] text-muted-foreground">{eyebrow}</p>
          <h2 className="mt-2 text-balance text-5xl font-light tracking-tight md:text-6xl">{title}</h2>
        </div>
      </div>
      {description && (
        <p className="max-w-sm text-pretty text-lg leading-relaxed text-muted-foreground">{description}</p>
      )}
    </div>
  )
}
