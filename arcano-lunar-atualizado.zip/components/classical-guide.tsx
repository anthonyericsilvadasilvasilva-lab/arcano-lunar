import { SectionHeading } from './section-heading'

const PLANETS = [
  ['Sol', 'Luminar diurno', 'Vitalidade, autoridade, propósito e princípio de centralidade.'],
  ['Lua', 'Luminar noturno', 'Corpo, hábitos, necessidades, memória e variação.'],
  ['Mercúrio', 'Planeta variável', 'Pensamento, linguagem, comércio, cálculo e mediação.'],
  ['Vênus', 'Benéfico', 'Vínculos, prazer, concórdia, beleza e valores.'],
  ['Marte', 'Maléfico', 'Corte, conflito, iniciativa, coragem e separação.'],
  ['Júpiter', 'Benéfico', 'Expansão, justiça, proteção, confiança e sentido.'],
  ['Saturno', 'Maléfico', 'Limites, tempo, estrutura, demora e responsabilidade.'],
]

const ELEMENTS = [
  ['Fogo', 'Áries · Leão · Sagitário', 'Ação, impulso e afirmação.'],
  ['Terra', 'Touro · Virgem · Capricórnio', 'Forma, sustentação e concretude.'],
  ['Ar', 'Gêmeos · Libra · Aquário', 'Relação, pensamento e circulação.'],
  ['Água', 'Câncer · Escorpião · Peixes', 'Sensibilidade, vínculo e assimilação.'],
]

const MODALITIES = [
  ['Cardinal', 'Áries · Câncer · Libra · Capricórnio', 'Iniciam os ciclos.'],
  ['Fixo', 'Touro · Leão · Escorpião · Aquário', 'Conservam e estabilizam.'],
  ['Mutável', 'Gêmeos · Virgem · Sagitário · Peixes', 'Adaptam e fazem a transição.'],
]

export function ClassicalGuide() {
  return (
    <section id="fundamentos" className="scroll-mt-16 border-b">
      <div className="mx-auto max-w-6xl px-5 py-20">
        <SectionHeading
          index="I"
          eyebrow="Chaves de leitura"
          title="A gramática do céu"
          description="Uma introdução prática à estrutura tradicional: os sete astros, os quatro elementos, as três modalidades e as dignidades essenciais."
        />
        <div className="mt-12 grid gap-px border bg-border md:grid-cols-2">
          <div className="bg-background p-6 md:p-8">
            <p className="font-mono text-[10px] uppercase tracking-[0.25em] text-muted-foreground">Os sete astros</p>
            <div className="mt-5 divide-y">
              {PLANETS.map(([name, role, meaning]) => (
                <div key={name} className="grid gap-1 py-4 sm:grid-cols-[8rem_1fr]">
                  <div>
                    <h3 className="text-xl italic">{name}</h3>
                    <p className="font-mono text-[9px] uppercase tracking-[0.15em] text-muted-foreground">{role}</p>
                  </div>
                  <p className="text-sm leading-relaxed text-muted-foreground">{meaning}</p>
                </div>
              ))}
            </div>
          </div>
          <div className="flex flex-col gap-10 bg-background p-6 md:p-8">
            <div>
              <p className="font-mono text-[10px] uppercase tracking-[0.25em] text-muted-foreground">Quatro elementos</p>
              <div className="mt-5 divide-y">
                {ELEMENTS.map(([name, signs, meaning]) => (
                  <div key={name} className="py-4">
                    <div className="flex flex-wrap items-baseline justify-between gap-2">
                      <h3 className="text-xl italic">{name}</h3>
                      <span className="font-mono text-[9px] text-muted-foreground">{signs}</span>
                    </div>
                    <p className="mt-1 text-sm text-muted-foreground">{meaning}</p>
                  </div>
                ))}
              </div>
            </div>
            <div>
              <p className="font-mono text-[10px] uppercase tracking-[0.25em] text-muted-foreground">Três modalidades</p>
              <div className="mt-5 divide-y">
                {MODALITIES.map(([name, signs, meaning]) => (
                  <div key={name} className="py-4">
                    <h3 className="text-lg italic">{name}</h3>
                    <p className="font-mono text-[9px] text-muted-foreground">{signs}</p>
                    <p className="mt-1 text-sm text-muted-foreground">{meaning}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
        <div className="mt-8 grid gap-6 border p-6 md:grid-cols-2 md:p-8">
          <div>
            <p className="font-mono text-[10px] uppercase tracking-[0.25em] text-muted-foreground">Dignidades essenciais</p>
            <h3 className="mt-2 text-2xl italic">O planeta e o signo</h3>
            <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
              Domicílio, exaltação, exílio, queda e peregrinação descrevem condições simbólicas do planeta no signo. Não são notas morais nem garantias de acontecimentos.
            </p>
          </div>
          <div className="flex flex-col justify-center gap-3 text-sm leading-relaxed">
            <p><strong>Domicílio:</strong> o planeta está em um signo sob sua regência.</p>
            <p><strong>Exaltação:</strong> ocupa um signo em que sua expressão é tradicionalmente elevada.</p>
            <p><strong>Exílio e queda:</strong> posições opostas ao domicílio e à exaltação.</p>
            <p><strong>Peregrino:</strong> não possui uma dessas dignidades essenciais maiores no signo.</p>
          </div>
        </div>
        <p className="mt-5 max-w-3xl text-xs leading-relaxed text-muted-foreground">
          Método tradicional: utiliza Sol, Lua, Mercúrio, Vênus, Marte, Júpiter e Saturno como os sete astros clássicos. Urano, Netuno e Plutão podem ser estudados em abordagens modernas, mas não substituem os regentes tradicionais aqui adotados. Signos zodiacais e casas astrológicas são conceitos diferentes.
        </p>
      </div>
    </section>
  )
}
