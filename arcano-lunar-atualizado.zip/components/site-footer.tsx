export function SiteFooter() {
  return (
    <footer>
      <div className="mx-auto flex max-w-6xl flex-col gap-6 px-5 py-12 md:flex-row md:items-end md:justify-between">
        <div>
          <p className="text-4xl italic">Arcano Lunar</p>
          <p className="mt-2 max-w-sm text-muted-foreground">
            Um almanaque para contemplação. As leituras são simbólicas e não substituem aconselhamento
            profissional.
          </p>
        </div>
        <p className="font-mono text-[10px] uppercase tracking-[0.25em] text-muted-foreground">
          Impresso à luz da lua · MMXXVI
        </p>
      </div>
    </footer>
  )
}
