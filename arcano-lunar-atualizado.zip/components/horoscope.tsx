'use client'

import { useState } from 'react'
import { ZODIAC } from '@/lib/astro-data'
import { useSky } from '@/hooks/use-sky'
import { signReading } from '@/lib/messages'
import { SectionHeading } from './section-heading'


export function Horoscope() {
  const sky = useSky()
  const [selected, setSelected] = useState<string | null>(null)
  const activeName = selected ?? sky?.sun.name ?? ZODIAC[0].name
  const sign = ZODIAC.find((s) => s.name === activeName) ?? ZODIAC[0]
  const reading = sky ? signReading(sign, sky.moon, sky.planets, sky.sun) : null

  return (
    <section id="horoscopo" className="scroll-mt-20 border-b">
      <div className="mx-auto max-w-6xl px-5 py-20">
        <SectionHeading
          index="IV"
          eyebrow="Signos solares"
          title="Horóscopo lunar"
          description="Escolha seu signo solar. Esta leitura acompanha o céu do momento e o regente tradicional do signo; não substitui um mapa natal calculado com data, hora e local de nascimento."
        />

        <div
          aria-label="Seleção do signo solar"
          className="mt-12 grid grid-cols-3 border-t border-l sm:grid-cols-4 lg:grid-cols-6"
        >
          {ZODIAC.map((s) => {
            const active = s.name === sign.name
            return (
              <button
                key={s.name}
                type="button"
                aria-pressed={active}
                onClick={() => setSelected(s.name)}
                className={`flex flex-col items-center gap-1 border-r border-b px-2 py-5 transition-colors focus-visible:outline-2 focus-visible:-outline-offset-4 focus-visible:outline-foreground ${active ? 'bg-foreground text-background' : 'hover:bg-accent'}`}
              >
                <span className={`text-xl ${active ? 'text-background/70' : 'text-muted-foreground'}`} aria-hidden="true">{s.symbol}</span>
                <span className="text-lg">{s.name}</span>
                <span className={`font-mono text-[9px] uppercase tracking-[0.15em] ${active ? 'text-background/60' : 'text-muted-foreground'}`}>
                  {s.dates}
                </span>
              </button>
            )
          })}
        </div>

        <article className="mt-10 grid gap-10 border p-6 md:grid-cols-[1fr_2fr] md:p-10" aria-live="polite">
          <div className="flex flex-col gap-6">
            <div>
              <span className="font-mono text-xs uppercase tracking-[0.3em] text-muted-foreground">
                Signo solar · {sign.dates}
              </span>
              <h3 className="mt-3 text-5xl font-light italic">{sign.name}</h3>
            </div>
            <dl className="grid grid-cols-2 gap-4 font-mono text-[11px] uppercase tracking-[0.2em]">
              <Detail label="Elemento" value={sign.element} />
              <Detail label="Modalidade" value={sign.modality} />
              <Detail label="Regente tradicional" value={sign.ruler} />
              <Detail label="Lua atual" value={sky?.moon.sign.name ?? '—'} />
            </dl>
          </div>
          <div className="flex flex-col justify-center gap-6 md:border-l md:pl-10">
            <p className="font-mono text-[11px] uppercase tracking-[0.3em] text-muted-foreground">
              Leitura do ciclo · relações por signo
            </p>
            {reading ? (
              <>
                <p className="text-pretty text-2xl leading-relaxed md:text-3xl">{reading.lunar}</p>
                <ReadingLine label={`Lua em ${sky?.moon.sign.name}`} text={reading.relation} />
                <ReadingLine label={`Regente · ${reading.rulerName}`} text={reading.ruler} />
              </>
            ) : (
              <p className="text-2xl">Consultando o céu…</p>
            )}
          </div>
        </article>
        <p className="mt-4 max-w-3xl text-xs leading-relaxed text-muted-foreground">As relações entre o signo solar e o signo lunar são lidas por signo inteiro. Sem os graus do mapa natal, não afirmamos aspectos exatos nem interpretamos casas astrológicas.</p>
      </div>
    </section>
  )
}

function Detail({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex flex-col gap-1 border-t pt-3">
      <dt className="text-muted-foreground">{label}</dt>
      <dd className="font-serif text-lg normal-case tracking-normal">{value}</dd>
    </div>
  )
}

function ReadingLine({ label, text }: { label: string; text: string }) {
  return (
    <div className="flex flex-col gap-1 border-t pt-4">
      <p className="font-mono text-[10px] uppercase tracking-[0.25em] text-muted-foreground">{label}</p>
      <p className="text-pretty text-lg leading-relaxed">{text}</p>
    </div>
  )
}
