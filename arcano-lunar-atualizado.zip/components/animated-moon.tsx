'use client'

import { useEffect, useRef, useState } from 'react'
import { cn } from '@/lib/utils'
import { MoonGlyph } from './moon-glyph'

const CYCLE_MS = 2800
const TWEEN_MS = 700

const easeInOut = (t: number) => (t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2)
const easeOut = (t: number) => 1 - Math.pow(1 - t, 3)
const wrap = (f: number) => ((f % 1) + 1) % 1

type AnimatedMoonProps = {
  fraction: number
  className?: string
}

export function AnimatedMoon({ fraction, className }: AnimatedMoonProps) {
  const ref = useRef<HTMLDivElement>(null)
  const frame = useRef<number>(0)
  const current = useRef(fraction)
  const target = useRef(fraction)
  const [shown, setShown] = useState(fraction)
  const [visible, setVisible] = useState(false)

  const run = (from: number, delta: number, duration: number, ease: (t: number) => number) => {
    cancelAnimationFrame(frame.current)
    const start = performance.now()
    const step = (now: number) => {
      const t = Math.min(1, (now - start) / duration)
      const value = wrap(from + delta * ease(t))
      current.current = value
      setShown(value)
      if (t < 1) frame.current = requestAnimationFrame(step)
    }
    frame.current = requestAnimationFrame(step)
  }

  useEffect(() => {
    const el = ref.current
    if (!el) return
    const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches
    let away = true

    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting && away) {
          away = false
          setVisible(true)
          if (!reduced) run(target.current, 1, CYCLE_MS, easeInOut)
        } else if (!entry.isIntersecting) {
          away = true
          setVisible(false)
          cancelAnimationFrame(frame.current)
          current.current = target.current
          setShown(target.current)
        }
      },
      { threshold: 0.35 },
    )
    observer.observe(el)
    return () => {
      observer.disconnect()
      cancelAnimationFrame(frame.current)
    }
  }, [])

  useEffect(() => {
    if (target.current === fraction) return
    target.current = fraction
    let delta = fraction - current.current
    if (delta > 0.5) delta -= 1
    if (delta < -0.5) delta += 1
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
      current.current = fraction
      setShown(fraction)
      return
    }
    run(current.current, delta, TWEEN_MS, easeOut)
  }, [fraction])

  return (
    <div
      ref={ref}
      className={cn(
        'transition-[opacity,transform,filter] duration-[1400ms] ease-[cubic-bezier(0.22,1,0.36,1)] motion-reduce:transition-none',
        visible ? 'scale-100 opacity-100 blur-0' : 'scale-95 opacity-0 blur-sm',
        className,
      )}
    >
      <MoonGlyph fraction={shown} textured className="aspect-square w-full" />
    </div>
  )
}
