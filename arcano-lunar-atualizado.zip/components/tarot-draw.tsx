'use client'

import Image from 'next/image'
import { useEffect, useRef, useState } from 'react'
import { useSky } from '@/hooks/use-sky'
import { MAJOR_ARCANA, type TarotCard } from '@/lib/astro-data'
import { SectionHeading } from './section-heading'

const SLOTS = ['Passado', 'Presente', 'Futuro'] as const
const FLIP_MS = 700

function drawThree(): TarotCard[] {
  const pool = [...MAJOR_ARCANA]
  for (let i = pool.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1))
    ;[pool[i], pool[j]] = [pool[j], pool[i]]
  }
  return pool.slice(0, 3)
}

export function TarotDraw() {
  const sky = useSky()
  const [cards, setCards] = useState<TarotCard[] | null>(null)
  const [revealed, setRevealed] = useState<boolean[]>([false, false, false])
  const [shuffling, setShuffling] = useState(false)
  const shuffleTimer = useRef<ReturnType<typeof setTimeout> | null>(null)

  useEffect(() => () => {
    if (shuffleTimer.current) clearTimeout(shuffleTimer.current)
  }, [])

  function shuffle() {
    if (shuffling) return
    setRevealed([false, false, false])
    setShuffling(true)
    // Swap the deck only after the flip-back finishes so new faces are never visible.
    shuffleTimer.current = setTimeout(() => {
      setCards(null)
      setShuffling(false)
    }, FLIP_MS)
  }

  function reveal(i: number) {
    if (shuffling) return
    if (!cards) setCards(drawThree())
    setRevealed((prev) => prev.map((r, idx) => (idx === i ? true : r)))
  }

  return (
    <section id="tarot" className="scroll-mt-16 border-b bg-foreground text-background">
      <div className="mx-auto max-w-6xl px-5 py-20 [&_.text-muted-foreground]:text-background/60">
        <SectionHeading
          index="III"
          eyebrow="Arcanos Maiores"
          title="Tiragem de três cartas"
          description={
            sky
              ? `Leitura simbólica para reflexão. A Lua está em ${sky.moon.sign.name}, na fase ${sky.moon.phase.name}; isso não altera o sorteio das cartas.`
              : 'Tiragem simbólica independente dos cálculos astrológicos. Pense em uma pergunta e revele passado, presente e futuro.'
          }
        />

        <div className="mt-12 grid grid-cols-3 gap-3 sm:gap-8">
          {SLOTS.map((slot, i) => {
            const card = cards?.[i]
            const isOpen = revealed[i] && card
            return (
              <div key={slot} className="flex flex-col gap-3">
                <p className="font-mono text-[9px] uppercase tracking-[0.2em] text-background/60 sm:text-[11px] sm:tracking-[0.3em]">
                  {String(i + 1).padStart(2, '0')} · {slot}
                </p>
                <button
                  type="button"
                  onClick={() => reveal(i)}
                  disabled={!!isOpen || shuffling}
                  aria-label={isOpen ? `${slot}: ${card.name}` : `Revelar carta do ${slot.toLowerCase()}`}
                  className="group aspect-[2/3] w-full [perspective:1200px] focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-background"
                >
                  <div
                    className={`relative size-full transition-transform duration-700 [transform-style:preserve-3d] motion-reduce:transition-none ${isOpen ? '[transform:rotateY(180deg)]' : 'group-hover:-translate-y-1'}`}
                  >
                    <div className="absolute inset-0 overflow-hidden border border-background/30 [backface-visibility:hidden]">
                      <Image src="/images/card-back.png" alt="" fill sizes="(min-width: 640px) 30vw, 33vw" className="analog object-cover" />
                    </div>
                    <div className="absolute inset-0 flex flex-col border border-foreground bg-background p-1.5 text-foreground [backface-visibility:hidden] [transform:rotateY(180deg)] sm:p-3">
                      {card && <CardFace card={card} />}
                    </div>
                  </div>
                </button>
              </div>
            )
          })}
        </div>

        <div className="mt-10 flex justify-center">
          <button
            type="button"
            onClick={shuffle}
            disabled={shuffling}
            className="border disabled:opacity-50 border-background px-8 py-3 font-mono text-xs uppercase tracking-[0.25em] transition-colors hover:bg-background hover:text-foreground"
          >
            Embaralhar novamente
          </button>
        </div>
      </div>
    </section>
  )
}

function CardFace({ card }: { card: TarotCard }) {
  return (
    <div className="flex size-full flex-col items-center justify-between border border-foreground px-1 py-2 text-center sm:p-4">
      <span className="font-mono text-[10px] tracking-[0.2em] sm:text-sm">{card.numeral}</span>
      <svg viewBox="0 0 100 100" className="size-10 sm:size-20" aria-hidden="true">
        <circle cx="50" cy="50" r="30" fill="none" stroke="currentColor" strokeWidth="1" />
        <circle cx="50" cy="50" r="18" fill="currentColor" />
        {Array.from({ length: 16 }).map((_, i) => {
          const a = (i / 16) * Math.PI * 2
          return (
            <line
              key={i}
              x1={50 + Math.cos(a) * 36}
              y1={50 + Math.sin(a) * 36}
              x2={50 + Math.cos(a) * (i % 2 ? 42 : 48)}
              y2={50 + Math.sin(a) * (i % 2 ? 42 : 48)}
              stroke="currentColor"
              strokeWidth="1"
            />
          )
        })}
      </svg>
      <span className="text-balance text-[11px] uppercase leading-tight tracking-[0.08em] sm:text-2xl sm:tracking-[0.12em]">
        {card.name}
      </span>
    </div>
  )
}
