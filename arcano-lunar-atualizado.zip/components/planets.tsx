'use client'

import { useSky } from '@/hooks/use-sky'
import { CONDITION_LABEL, planetMessage, planetTitle } from '@/lib/messages'
import type { PlanetState } from '@/lib/sky'
import { SectionHeading } from './section-heading'

const shortDay = new Intl.DateTimeFormat('pt-BR', { day: 'numeric', month: 'short' })

export function Planets() {
  const sky = useSky()

  return (
    <section id="planetas" className="scroll-mt-16 border-b">
      <div className="mx-auto max-w-6xl px-5 py-20">
        <SectionHeading
          index="II"
          eyebrow="Sete astros tradicionais"
          title="O céu em movimento"
          description="Posições geocêntricas calculadas para o momento. Aqui aparecem os cinco planetas errantes; Sol e Lua estão destacados no calendário. São condições do céu coletivo, não posições do seu mapa natal."
        />
        <div className="mt-12 grid gap-px border bg-border md:grid-cols-2">
          {sky
            ? sky.planets.map((p) => <PlanetCard key={p.name} planet={p} />)
            : Array.from({ length: 4 }).map((_, i) => <div key={i} className="h-72 animate-pulse bg-muted" />)}
        </div>
      </div>
    </section>
  )
}

function PlanetCard({ planet }: { planet: PlanetState }) {
  const range = `${planet.since ? shortDay.format(planet.since) : '…'} — ${planet.until ? shortDay.format(planet.until) : '…'}`
  const label = planet.retrograde ? 'Retrógrado' : CONDITION_LABEL[planet.condition]
  const angle = Math.PI * (1 - planet.progress)
  const x = 150 + Math.cos(angle) * 130
  const y = 110 - Math.sin(angle) * 80

  return (
    <article className="flex flex-col gap-5 bg-background p-6 md:p-8">
      <p className="font-mono text-[10px] uppercase tracking-[0.25em] text-muted-foreground">{range}</p>
      <h3 className="text-balance text-3xl font-light italic md:text-4xl">{planetTitle(planet)}</h3>
      <dl className="grid grid-cols-2 gap-4">
        <div>
          <dt className="font-mono text-[10px] uppercase tracking-[0.2em] text-muted-foreground">{label}</dt>
          <dd className="text-xl">{planet.name}</dd>
        </div>
        <div>
          <dt className="font-mono text-[10px] uppercase tracking-[0.2em] text-muted-foreground">Signo</dt>
          <dd className="text-xl">
            {planet.sign.name} <span className="font-mono text-xs text-muted-foreground">{planet.degree}°</span>
          </dd>
        </div>
      </dl>
      <p className="text-pretty leading-relaxed text-muted-foreground">{planetMessage(planet)}</p>
      <div className="relative">
        <svg viewBox="0 0 300 120" className="w-full" aria-hidden="true">
          <path d="M 20 110 Q 150 -50 280 110" fill="none" stroke="currentColor" strokeOpacity="0.2" strokeDasharray="2 4" />
          <path
            d="M 20 110 Q 150 -50 280 110"
            fill="none"
            stroke="currentColor"
            strokeWidth="1.5"
            pathLength={100}
            strokeDasharray={`${planet.progress * 100} 100`}
          />
          <circle cx={x} cy={y} r="9" fill="var(--background)" stroke="currentColor" strokeWidth="1.5" />
          <circle cx={x} cy={y} r="4" fill="currentColor" />
        </svg>
        <p className="absolute inset-x-0 bottom-1 text-center font-mono text-[11px] uppercase tracking-[0.25em]">
          {planet.daysLeft ? `Faltam ${planet.daysLeft} dias` : 'Longa permanência'}
        </p>
      </div>
    </article>
  )
}
