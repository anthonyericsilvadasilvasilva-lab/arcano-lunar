import { useId } from 'react'
import { moonLitPath } from '@/lib/moon'
import { cn } from '@/lib/utils'

type MoonGlyphProps = {
  fraction: number
  className?: string
  textured?: boolean
}

export function MoonGlyph({ fraction, className, textured = false }: MoonGlyphProps) {
  const clipId = useId()
  const isNew = fraction < 0.02 || fraction > 0.98
  const isFull = Math.abs(fraction - 0.5) < 0.02

  return (
    <svg viewBox="0 0 100 100" className={cn('block', className)} aria-hidden="true">
      <defs>
        <clipPath id={clipId}>
          {isFull ? <circle cx="50" cy="50" r="50" /> : <path d={moonLitPath(fraction)} />}
        </clipPath>
        <clipPath id={`${clipId}-disc`}>
          <circle cx="50" cy="50" r="50" />
        </clipPath>
      </defs>
      {textured ? (
        <>
          <image
            href="/images/moon.png"
            x="-36"
            y="-36"
            width="172"
            height="172"
            opacity="0.12"
            style={{ filter: 'grayscale(1)' }}
            clipPath={`url(#${clipId}-disc)`}
          />
          {!isNew && (
            <image
              href="/images/moon.png"
              x="-36"
              y="-36"
              width="172"
              height="172"
              clipPath={`url(#${clipId})`}
              style={{ filter: 'grayscale(1) contrast(1.1)' }}
            />
          )}
        </>
      ) : (
        <>
          <circle cx="50" cy="50" r="48.5" fill="none" stroke="currentColor" strokeWidth="1.5" />
          {!isNew && <rect width="100" height="100" fill="currentColor" clipPath={`url(#${clipId})`} />}
        </>
      )}
    </svg>
  )
}
